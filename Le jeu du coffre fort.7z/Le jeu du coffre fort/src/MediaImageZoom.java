
public class MediaImageZoom {
	

}
