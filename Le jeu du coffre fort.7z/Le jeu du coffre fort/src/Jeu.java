
public class Jeu {
		public static void main(String[] args) {

			// Affichage de l'interface
			Partie Nouvelle = new Partie("Facile");
		  }
	}

